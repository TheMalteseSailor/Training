#pragma warning(disable : 4996)
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <windows.h> 

#pragma comment(lib, "ws2_32.lib")

#define PORT 8080
#define BUFFER_SIZE 4096
#define MAX_CLIENTS 10
#define KEY "STATIC_RC4_KEY_123"

typedef struct {
    unsigned char s[256];
    int i, j;
} RC4_CTX;

void rc4_init(RC4_CTX* ctx, const unsigned char* key, int key_len) {
    for (int i = 0; i < 256; i++) ctx->s[i] = (unsigned char)i;
    for (int i = 0, j = 0; i < 256; i++) {
        j = (j + ctx->s[i] + key[i % key_len]) % 256;
        unsigned char temp = ctx->s[i];
        ctx->s[i] = ctx->s[j];
        ctx->s[j] = temp;
    }
    ctx->i = ctx->j = 0;
}

void rc4_crypt(RC4_CTX* ctx, unsigned char* data, int len) {
    int i = ctx->i, j = ctx->j;
    unsigned char* s = ctx->s;
    for (int k = 0; k < len; k++) {
        i = (i + 1) % 256;
        j = (j + s[i]) % 256;
        unsigned char temp = s[i];
        s[i] = s[j];
        s[j] = temp;
        data[k] ^= s[(s[i] + s[j]) % 256];
    }
    ctx->i = i; ctx->j = j;
}

int main() {
    WSADATA wsa;
    SOCKET master, new_socket, client_socket[MAX_CLIENTS];
    struct sockaddr_in server, address;
    int addrlen = sizeof(struct sockaddr_in);
    char buffer[BUFFER_SIZE];
    fd_set readfds;

    // Resolve full path for the file in the EXE directory
    char path[MAX_PATH];
    GetModuleFileNameA(NULL, path, MAX_PATH);
    char* last_slash = strrchr(path, '\\');
    if (last_slash) *(last_slash + 1) = '\0';
    strcat(path, "decrypted_output.txt");

    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) return 1;

    for (int i = 0; i < MAX_CLIENTS; i++) client_socket[i] = 0;

    master = socket(AF_INET, SOCK_STREAM, 0);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(PORT);

    if (bind(master, (struct sockaddr*)&server, sizeof(server)) == SOCKET_ERROR) return 1;
    listen(master, 3);

    printf("Server Listening on Port %d\n", PORT);
    printf("Writing to: %s\n", path);

    // Open file for appending
    FILE* fptr = fopen(path, "ab");
    if (!fptr) {
        printf("Error: Could not open file for writing.\n");
        return 1;
    }

    while (1) {
        FD_ZERO(&readfds);
        FD_SET(master, &readfds);
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (client_socket[i] > 0) FD_SET(client_socket[i], &readfds);
        }

        select(0, &readfds, NULL, NULL, NULL);

        if (FD_ISSET(master, &readfds)) {
            new_socket = accept(master, (struct sockaddr*)&address, &addrlen);
            for (int i = 0; i < MAX_CLIENTS; i++) {
                if (client_socket[i] == 0) {
                    client_socket[i] = new_socket;
                    printf("New client connected.\n");
                    break;
                }
            }
        }

        for (int i = 0; i < MAX_CLIENTS; i++) {
            SOCKET s = client_socket[i];
            if (FD_ISSET(s, &readfds)) {
                memset(buffer, 0, BUFFER_SIZE);
                int valread = recv(s, buffer, BUFFER_SIZE - 1, 0);

                if (valread <= 0) {
                    closesocket(s);
                    client_socket[i] = 0;
                    printf("Client disconnected.\n");
                }
                else {
                    // Decrypt
                    RC4_CTX ctx;
                    rc4_init(&ctx, (const unsigned char*)KEY, (int)strlen(KEY));
                    rc4_crypt(&ctx, (unsigned char*)buffer, valread);

                    // 1. Write to Terminal
                    printf("Decrypted: %s\n", buffer);

                    // 2. Write to File
                    fwrite(buffer, 1, valread, fptr);
                    fprintf(fptr, "\n"); // Add newline for readability in file
                    fflush(fptr);
                }
            }
        }
    }

    fclose(fptr);
    WSACleanup();
    return 0;
}