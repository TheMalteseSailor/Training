from flask import Flask, render_template, jsonify
import os

app = Flask(__name__)

# Ensure this path matches the directory where your C server is writing the file
FILE_PATH = "decrypted_output.txt"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/data')
def get_data():
    if os.path.exists(FILE_PATH):
        with open(FILE_PATH, 'r') as f:
            # Read all lines and return them as a list
            content = f.readlines()
        return jsonify({"data": content})
    return jsonify({"data": ["File not found yet..."]})

if __name__ == '__main__':
    app.run(debug=True, port=5000)