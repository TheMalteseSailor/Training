import socket

# Must match C Server precisely
SERVER_IP = "127.0.0.1"
SERVER_PORT = 8080
STATIC_KEY = b"STATIC_RC4_KEY_123"

def rc4_crypt(key, data):
    S = list(range(256))
    j = 0
    for i in range(256):
        j = (j + S[i] + key[i % len(key)]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    res = []
    for char in data:
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        res.append(char ^ S[(S[i] + S[j]) % 256])
    return bytes(res)

def main():
    message = "Secret data from Python client!\n"
    #message = "<script>alert('1')</script>\n"
    encrypted = rc4_crypt(STATIC_KEY, message.encode())
    
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((SERVER_IP, SERVER_PORT))
            s.sendall(encrypted)
            print(f"Sent: {message}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()